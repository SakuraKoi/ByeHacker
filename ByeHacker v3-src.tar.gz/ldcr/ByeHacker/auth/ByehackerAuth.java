package ldcr.ByeHacker.auth;

import lombok.Getter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import ldcr.ByeHacker.ByeHacker;
import ldcr.ByeHacker.Tasks.DetectedKickThread;
import ldcr.ByeHacker.Tasks.TimeoutKickThread;
import ldcr.ByeHacker.Utils.AuthKeyGenerator;
import ldcr.ByeHacker.Utils.RandomUtils;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;

public class ByehackerAuth {
	private static final int AUTH_KEY_COUNT = 4;
	private static final int SPEC_KEY_COUNT = 2;
	private static final int FAKE_KEY_COUNT = 6;
	private static final String[] CLEAR_CHAT_1 = new String[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "",
			"", "" };
	private static final String[] CLEAR_CHAT_2 = new String[] { "", "" };
	private static final String[] RETRY_MESSAGE = new String[] { "", "", "", "", "", "", "", "", "", "", "", "", "",
			"", "§b§l作弊验证 §7>> §c验证失败, 请重试~", "", "", "", "" }; //             §7如果您使用了自定义字体, 按钮可能错位, 请以提示按钮序号为准
	private final Player player;
	private ByehackerQuestion question;
	private final LinkedList<ByehackerKey> keys = new LinkedList<>();
	private final LinkedList<ByehackerKey> validKeys = new LinkedList<>();
	private final ArrayList<ByehackerKey> fakeKeys = new ArrayList<>();
	private int pointer = -1;
	private ByehackerKey currentKey;
	private boolean hacking = false;
	private boolean lastCheck = false;
	private boolean retry = false;
	private TextComponent title;
	@Getter
	private final TimeoutKickThread timeoutThread;

	public ByehackerAuth(final Player player) {
		this.player = player;
		timeoutThread = new TimeoutKickThread(player, this);
	}

	private void generateKeys() {
		question = RandomUtils.selectRandom(ByehackerQuestion.values());
		for (int i = 0; i < AUTH_KEY_COUNT; i++) {
			keys.add(AuthKeyGenerator.generateValidKey(i, question));
		}
		for (int i = 0; i < SPEC_KEY_COUNT; i++) {
			keys.add(AuthKeyGenerator.generateSpecKey(question));
		}
		for (int i = 0; i < FAKE_KEY_COUNT; i++) {
			keys.add(AuthKeyGenerator.generateFakeKey(i, question));
		}
		Collections.shuffle(keys);
		for (final ByehackerKey key : keys) {
			if (key.isFakeKey()) {
				fakeKeys.add(key);
			} else {
				validKeys.add(key);
			}
		}
		/*
		 * final TextComponent display1 = new TextComponent("████");
		 * display1.setColor(ChatColor.AQUA); display1.setHoverEvent(new
		 * HoverEvent(HoverEvent.Action.SHOW_TEXT, new TextComponent[] {new
		 * TextComponent(question.getDisplay())})); display1.setClickEvent(new
		 * ClickEvent(ClickEvent.Action.RUN_COMMAND,
		 * ".Nooooo_AuthBypass_mod_is_not_allowed_awa")); title = new
		 * TextComponent(new TextComponent("§b§l作弊验证 §7>> §a请打开聊天用鼠标从左到右依次点击: "
		 * ), display1, new TextComponent(" §6<-- 刮刮乐"));
		 */
		title = new TextComponent(new TextComponent("§b§l作弊验证 §7>> §a请打开聊天用鼠标从左到右依次点击: "), new TextComponent(question.getDisplay()));
	}

	private boolean hasNextPointer() {
		return pointer < validKeys.size();
	}

	private boolean matchMessage(final String message) {
		for (final ByehackerKey key : keys) {
			if (key.match(message)) return true;
		}
		return false;
	}

	private void nextPointer() {
		pointer++;
		if (!hasNextPointer()) {
			timeoutThread.cancel();
			endCheck();
			return;
		}
		currentKey = validKeys.get(pointer);
		sendAuthMessage();
		if (hacking && (Math.random() > 0.5)) {
			Bukkit.getScheduler().runTask(ByeHacker.instance, new DetectedKickThread(player));
		}
	}
	private void endCheck() {
		sendAuthMessage();
		lastCheck = true;
		player.sendMessage("§b§l作弊验证 §7>> §e正在检查您的客户端, 请稍候...");
		Bukkit.getScheduler().runTaskLater(ByeHacker.instance, new Runnable() {
			@Override
			public void run() {
				if (player.isOnline()) {
					if (hacking) {
						Bukkit.getScheduler().runTask(ByeHacker.instance, new DetectedKickThread(player));
						return;
					}
					ByeHacker.passAuth(player);
				}
			}
		}, 20);
	}

	public boolean onChat(final String message) {
		if (lastCheck) return false;
		if (currentKey.match(message)) {
			if (!currentKey.isPassed(message)) {
				hacking = true;
				ByeHacker.instance.banHacker(player);
			}
			nextPointer();
		} else if (matchMessage(message)) {
			resetKey();
		}
		return false;
	}

	public void requestAuth() {
		generateKeys();
		nextPointer();
		timeoutThread.start();
		Bukkit.getScheduler().runTaskLater(ByeHacker.instance, new Runnable() {
			@Override
			public void run() {
				sendAuthMessage();
			}
		}, 20);
	}

	private void resetKey() {
		retry = true;
		keys.clear();
		validKeys.clear();
		fakeKeys.clear();
		pointer = -1;
		currentKey = null;
		generateKeys();
		nextPointer();
		Bukkit.getScheduler().runTaskLater(ByeHacker.instance, new Runnable() {
			@Override
			public void run() {
				retry = false;
				sendAuthMessage();
			}
		}, 20);
	}

	public void sendAuthMessage() {
		if (lastCheck) return;
		if (retry) {
			player.sendMessage(RETRY_MESSAGE);
			return;
		}
		// final TextComponent display = new
		// TextComponent(question.getDisplay());
		TextComponent auth;
		{
			final TextComponent base = new TextComponent("              "); // "§b§l作弊验证 §7>>"
			final LinkedList<TextComponent> boxes = new LinkedList<>();
			boxes.add(base);
			int valid = 0;
			for (int i = 0, length = keys.size(); i < length; i++) {
				final ByehackerKey key = keys.get(i);
				if (!key.isFakeKey()) {
					valid++;
				}
				final TextComponent sub = key.isFakeKey() ? key.getValidKey() : (valid > pointer) ? key.getValidKey() : key.getPassedKey();
				sub.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, key.getLegalKey()));
				sub.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new TextComponent[] {
						new TextComponent("§b§l作弊验证 §6按钮 "+(i+1)) }));
				boxes.add(sub);
			}
			auth = new TextComponent(boxes.toArray(new TextComponent[0]));
		}
		player.sendMessage(CLEAR_CHAT_1);
		player.spigot().sendMessage(title);
		player.sendMessage("");
		player.spigot().sendMessage(new TextComponent(new TextComponent(new TextComponent(auth))));
		player.sendMessage(CLEAR_CHAT_2);
	}
}
