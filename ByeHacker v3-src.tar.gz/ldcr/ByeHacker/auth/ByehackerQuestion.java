package ldcr.ByeHacker.auth;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.TextComponent;

public enum ByehackerQuestion {
	GERRN_BLOCK() {
		@Override
		public String getDisplay() {
			return "§a原谅色方块";
		}
		@Override
		public TextComponent getValidKey() {
			final TextComponent text = new TextComponent(" ◆ ");
			text.setColor(ChatColor.GREEN);
			return text;
		}
		@Override
		public TextComponent getPassedKey() {
			final TextComponent text = new TextComponent(" ◆ ");
			text.setColor(ChatColor.YELLOW);
			return text;
		}
		@Override
		public TextComponent getFakeKey() {
			final TextComponent text = new TextComponent(" ◆ ");
			text.setColor(ChatColor.GRAY);
			return text;
		}
	},
	GAY() {

		@Override
		public String getDisplay() {
			return "§5充满Gay氛围的图案";
		}
		@Override
		public TextComponent getValidKey() {
			final TextComponent text = new TextComponent(" ♂ ");
			text.setColor(ChatColor.LIGHT_PURPLE);
			return text;
		}
		@Override
		public TextComponent getPassedKey() {
			final TextComponent text = new TextComponent(" ♂ ");
			text.setColor(ChatColor.YELLOW);
			return text;
		}
		@Override
		public TextComponent getFakeKey() {
			final TextComponent text = new TextComponent(" ♀ ");
			text.setColor(ChatColor.LIGHT_PURPLE);
			return text;
		}
	};/*
	UP_ARROW(){

		@Override
		public String getDisplay() {
			return "§b上半截实心的箭头";
		}
		@Override
		public TextComponent getValidKey() {
			final TextComponent text = new TextComponent(" ➣");
			text.setColor(ChatColor.AQUA);
			return text;
		}
		@Override
		public TextComponent getPassedKey() {
			final TextComponent text = new TextComponent(" ➣");
			text.setColor(ChatColor.YELLOW);
			return text;
		}
		@Override
		public TextComponent getFakeKey() {
			final TextComponent text = new TextComponent(" ➢");
			text.setColor(ChatColor.AQUA);
			return text;
		}
	},
	DOWN_ARROW(){

		@Override
		public String getDisplay() {
			return "§b下半截实心的箭头";
		}
		@Override
		public TextComponent getValidKey() {
			final TextComponent text = new TextComponent(" ➢");
			text.setColor(ChatColor.AQUA);
			return text;
		}
		@Override
		public TextComponent getPassedKey() {
			final TextComponent text = new TextComponent(" ➢");
			text.setColor(ChatColor.YELLOW);
			return text;
		}
		@Override
		public TextComponent getFakeKey() {
			final TextComponent text = new TextComponent(" ➣");
			text.setColor(ChatColor.AQUA);
			return text;
		}
	},
	NINE(){

		@Override
		public String getDisplay() {
			return "§b智商最高的数字";
		}
		private final String[] fakes = new String[] {
				"§b ①",
				"§b ②",
				"§b ③",
				"§b ④",
				"§b ⑤",
				"§b ⑥",
				"§b ⑦",
				"§b ⑧",
				"§b ⑩"
		};
		@Override
		public String[] getKeys() {
			return new String[] {"§b ⑨", RandomUtils.selectRandom(fakes), "§e ⑨"};
		}

	};*/
	public abstract String getDisplay();
	public abstract TextComponent getValidKey();
	public abstract TextComponent getPassedKey();
	public abstract TextComponent getFakeKey();
}
