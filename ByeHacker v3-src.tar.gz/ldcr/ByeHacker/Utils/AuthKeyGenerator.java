package ldcr.ByeHacker.Utils;

import ldcr.ByeHacker.auth.ByehackerKey;
import ldcr.ByeHacker.auth.ByehackerQuestion;

public class AuthKeyGenerator {
	private static final char[] OBF_KEY_CHAR = "il1I".toCharArray();
	private static final int AUTH_KEY_LENGTH = 32;
	private static final String[] SPEC_KEYS = new String[]{
			".killaura range 0.1 §f",
			".bind killaura none §f"
	};
	private static final String[] AUTH_PREFIXS = new String[] {
			".§fAntiHackedClient（_",
			"-§fAntiHackedClient（_"
	};
	public static ByehackerKey generateValidKey(int index, final ByehackerQuestion question) {
		index = index % AUTH_PREFIXS.length;
		final StringBuilder builder = new StringBuilder();
		builder.append(AUTH_PREFIXS[index]);
		for (int i = 0; i<AUTH_KEY_LENGTH; i++) {
			builder.append(RandomUtils.selectRandom(OBF_KEY_CHAR));
		}
		final String key = builder.toString();
		return new ByehackerKey(false, ".say " + key, key, question);
	}
	public static ByehackerKey generateFakeKey(int index, final ByehackerQuestion question) {
		index = index % AUTH_PREFIXS.length;
		final StringBuilder builder = new StringBuilder();
		builder.append(AUTH_PREFIXS[index]);
		for (int i = 0; i<AUTH_KEY_LENGTH; i++) {
			builder.append(RandomUtils.selectRandom(OBF_KEY_CHAR));
		}
		final String key = builder.toString();
		return new ByehackerKey(true, ".say " + key, key, question);
	}
	public static ByehackerKey generateSpecKey(final ByehackerQuestion question) {
		return new ByehackerKey(false, RandomUtils.selectRandom(SPEC_KEYS), null, question);
	}
}
